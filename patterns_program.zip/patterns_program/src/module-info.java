/**
 * 
 */
/**
 * @author ashwini
 *
 */
module patterns_program {
}